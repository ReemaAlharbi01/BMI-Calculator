import 'package:flutter/material.dart';

class colorss {
  static const Color red = Color(0xFF71B280);
  static const Color purple = Color(0xFF134E5E);
}

void sizes(contex) {
  var height = MediaQuery.of(contex).size.height;
  var width = MediaQuery.of(contex).size.width;

}
