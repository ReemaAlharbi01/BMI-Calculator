import 'package:bmi_calculator/UI/Hoverd.dart';
import 'package:bmi_calculator/UI/Themes.dart';
import 'package:flutter/material.dart';
import 'package:drop_shadow/drop_shadow.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/services.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Color backgroundColor = Color.fromARGB(255, 224, 224, 224);
  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  TextEditingController _weightt = TextEditingController();
  TextEditingController _heightt = TextEditingController();
  double w = 0.0, h = 0.0, result = 0.0;

  void _submitForm() {
    if (formkey.currentState!.validate()) {
      print('Login successful');
      setState(() {
        w = double.parse(_weightt.text);
        h = double.parse(_heightt.text);
        result = ((w / h) / h) * 10000;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    int time = DateTime.timestamp().hour;
    print('timmeeee: ${time}');
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    var sizedBox = SizedBox(
      height: height * 0.05,
    );
    return Scaffold(
        backgroundColor: backgroundColor,
        body: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
                height: height * 0.18,
                decoration: const BoxDecoration(
                    gradient: LinearGradient(colors: [
                      colorss.purple,
                      Color.fromARGB(255, 56, 132, 153)
                    ]),
                    borderRadius: const BorderRadius.only(
                        bottomRight: Radius.circular(90))),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SizedBox(
                      height: height * 0.05,
                    ),
                    ListTile(
                      title: text_style(
                          'Hello!', 30.0, Colors.white, FontWeight.bold, false),
                      subtitle: text_style(
                          ((time < 12) ? 'Good morning' : 'Good Evening'),
                          20.0,
                          Colors.white,
                          FontWeight.normal,
                          false),
                    ),
                  ],
                )),
            SizedBox(
              height: height * 0.05,
            ),
            Container(
              height: height,
              width: width - 30,
              margin: EdgeInsets.all(15),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          height: height / 6,
                          width: height / 6,
                          decoration: BoxDecoration(
                              color: Color.fromARGB(255, 231, 231, 231),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0xFFA7A9AF),
                                  offset: Offset(8.0, 8.0),
                                  blurRadius: 30.0,
                                ),
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(-8.0, -8.0),
                                  blurRadius: 30.0,
                                ),
                              ],
                              borderRadius: BorderRadius.circular(100)),
                        ),
                        Image.asset('assets/images/goal.png', width: height / 8)
                      ],
                    ),
                    sizedBox,
                    Container(
                      width: width - 100,
                      height: height * 0.2,
                      color: Colors.transparent,
                      child: Form(
                        key: formkey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            textFieldStyle('Wight', 'Enter in kg', true),
                            textFieldStyle('Hight', 'Enter in cm', false),
                          ],
                        ),
                      ),
                    ),
                    sizedBox,
                    GestureDetector(
                      onTap: () {
                        if (formkey.currentState!.validate()) {
                          print('Login successful');
                          setState(() {
                            w = double.parse(_weightt.text);
                            h = double.parse(_heightt.text);
                            result = ((w / h) / h) * 10000;
                          });
                        }
                      },
                      child: Container(
                        height: height * 0.07,
                        width: width - 100,
                        decoration: BoxDecoration(
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.white,
                                offset: Offset(-10, -10),
                                spreadRadius: 10,
                                blurRadius: 20),
                            BoxShadow(
                                color: Color.fromRGBO(158, 158, 158, 0.8),
                                offset: Offset(10, 10),
                                spreadRadius: 10,
                                blurRadius: 20)
                          ],
                          borderRadius: BorderRadius.circular(150),
                          gradient: const LinearGradient(
                              colors: [colorss.purple, Color(0xFF0CBABA)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight),
                        ),
                        child: Center(
                            child: text_style('Calculate', 25.0, Colors.white,
                                FontWeight.normal, false)),
                      ),
                    ),
                    sizedBox,
                    if (result > 0.0)
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                            color: backgroundColor,
                            boxShadow: const [
                              BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(-12, -12),
                                  spreadRadius: 10,
                                  blurRadius: 20),
                              BoxShadow(
                                  color: Color.fromRGBO(158, 158, 158, 0.8),
                                  offset: Offset(12, 12),
                                  spreadRadius: 10,
                                  blurRadius: 40)
                            ]),
                        height: height * 0.1,
                        width: width - 100,
                        child: Center(
                            child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            text_style(' Body Mass Index ', 25.0,
                                Colors.grey, FontWeight.bold, false),
                            text_style('${result.toStringAsFixed(3)}', 20.0,
                                colorss.purple, FontWeight.bold, false),
                          ],
                        )),
                      )
                  ],
                ),
              ),
            )
          ],
        ));
  }

  TextFormField textFieldStyle(lable, hint, bool isWight) {
    return TextFormField(
      controller: (isWight == true) ? _weightt : _heightt,
      keyboardType: TextInputType.number,
      inputFormatters: [FilteringTextInputFormatter.allow(RegExp("[0-9]"))],
      decoration: InputDecoration(
          // hintStyle: GoogleFonts.rubik(
          //     textStyle:
          //         const TextStyle(fontSize: 15, fontWeight: FontWeight.normal)),
          // labelStyle: GoogleFonts.rubik(
          //     textStyle:
          //         const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
          border: OutlineInputBorder(),
          labelText: '$lable ',
          hintText: '$hint'),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return "* Reguired";
        } else {
          return null;
        }
      },
    );
  }

  Text text_style(textt, fontSize, fontColor, fontWeight, shadow) => Text(
        textt,
        style: GoogleFonts.rubik(
            textStyle: TextStyle(
          fontSize: fontSize,
          color: fontColor,
          fontWeight: fontWeight,
          shadows: [
            if (shadow == true)
              const Shadow(
                  offset: Offset(3, 3), color: Colors.grey, blurRadius: 10),
            if (shadow == true)
              Shadow(
                  offset: Offset(-3, -3),
                  color: Colors.white.withOpacity(0.85),
                  blurRadius: 10)
          ],
        )),
      );
}
