import 'package:bmi_calculator/UI/HomePage.dart';
import 'package:bmi_calculator/UI/Themes.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:page_transition/page_transition.dart';

class SplashScrean extends StatefulWidget {
  const SplashScrean({super.key});

  @override
  State<SplashScrean> createState() => _SplashScreanState();
}

class _SplashScreanState extends State<SplashScrean> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(microseconds: 30), () {
      Navigator.push(
        context,
        PageTransition(
          type: PageTransitionType.fade, // Choose your desired transition type
          duration:
              Duration(milliseconds: 200), // Set the duration of the transition
          child:
              HomePage(), // Replace HomeScreen with your destination screen widget
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [colorss.purple, colorss.purple.withOpacity(0.80)],
            begin: Alignment.topLeft,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.only(top: height * 0.45),
                child: Stack(
                  children: [
                    Text(
                      'BMI',
                      style: GoogleFonts.abrilFatface(
                          textStyle: TextStyle(
                        fontSize: 60,
                        foreground: Paint()
                          ..style = PaintingStyle.stroke
                          ..strokeWidth = 6
                          ..color = Color.fromRGBO(0, 0, 0, 0.06)!,
                      )),
                    ),
                    Text(
                      'BMI',
                      style: GoogleFonts.abrilFatface(
                          textStyle: const TextStyle(
                        fontSize: 60,
                        color: Colors.white,
                        // // fontWeight: FontWeight.bold,
                        shadows: [
                          Shadow(
                            blurRadius: 4, // shadow blur
                            color:
                                Color.fromRGBO(0, 0, 0, 0.25), // shadow color
                            offset:
                                Offset(0, 4), // how much shadow will be shown
                          ),
                        ],
                      )),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: height * 0.3,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: width * 0.4,
                  // color: Colors.amber,
                  child: Image.asset(
                    'assets/images/logo.png',
                    width: width * 0.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
